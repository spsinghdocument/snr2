﻿using System;
using System.Drawing;

public partial class _Default : System.Web.UI.Page 
{    
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //write your code here
    }
}
